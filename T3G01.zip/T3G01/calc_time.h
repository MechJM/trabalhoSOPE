#pragma once

struct timespec timestamp();

double getInstant();
